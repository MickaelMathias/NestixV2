package bdd;

import javax.swing.*;
import java.sql.*;

public class C_requetes extends C_connexion{

    public void rechercheValeursComboBox(String requete, String ligne, JComboBox comboBox){
          
        try{
        ResultSet resultat = ex_Query(requete);  
        resultat.last();      
        String [] mes_valeurs = new String[resultat.getRow()+1];
        resultat.beforeFirst();
        mes_valeurs[0] = "Choisissez";
        int i = 1;
        while(resultat.next()){
            mes_valeurs[i] = resultat.getString(ligne);
            i+=1;}
            comboBox.setModel(new DefaultComboBoxModel<>(mes_valeurs));
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }
}